//selectors
let header=document.querySelector('.header');
let hamburgerMenu=document.querySelector('.hamburger-menu');

window.addEventListener('scrol',function(){
 let windowPosition = window.scrollY > 0;
 header.classList.toggle('active', windowPosition)
})
hamburgerMenu.addEventListener('click',function () {
    header.classList.toggle('menu-open');
})

//-------------Button-links-----------------//

//------------------room---------//
function link1()
{
  window.location.href="Suite Package.html";
}

function link2()
{
  window.location.href="Deluxe Package.html";
}
function link3()
{
  window.location.href="Premium Package.html";
}
//-----------Reservation------------//



//pooi&spa--not used

        function imgp1()
		{
			document.getElementById('B1').style.backgroundImage="url('pool1.jpg')";
		}
		function imgp2()
		{
			document.getElementById('B1').style.backgroundImage="url('pool2.jpg')";
		}
		function imgp3()
		{
			document.getElementById('B1').style.backgroundImage="url('pool3.jpg')";
		}
		function imgp4()
		{
			document.getElementById('B1').style.backgroundImage="url('pool4.jpg')";
		}
		function imgp5()
		{
			document.getElementById('B1').style.backgroundImage="url('pool5.jpg')";
		}
		function onimgp1()
		{
			document.getElementById('C1').style.height="175px";
		}
		function onimgp2()
		{
			document.getElementById('C2').style.height="175px";
		}
		function onimgp3()
		{
			document.getElementById('C3').style.height="175px";
		}
		function onimgp4()
		{
			document.getElementById('C4').style.height="175px";
		}
		function onimgp5()
		{
			document.getElementById('C5').style.height="175px";
		}
		function norimgp1()
		{
			document.getElementById('C1').style.height="";
		}
		function norimgp2()
		{
			document.getElementById('C2').style.height="";
		}
		function norimgp3()
		{
			document.getElementById('C3').style.height="";
		}
		function norimgp4()
		{
			document.getElementById('C4').style.height="";
		}
		function norimgp5()
		{
			document.getElementById('C5').style.height="";
		}

		function imgs1()
		{
			document.getElementById('D1').style.backgroundImage="url('spa1.jpg')";
		}
		function imgs2()
		{
			document.getElementById('D1').style.backgroundImage="url('spa2.jpg')";
		}
		function imgs3()
		{
			document.getElementById('D1').style.backgroundImage="url('spa3.jpg')";
		}
		function imgs4()
		{
			document.getElementById('D1').style.backgroundImage="url('spa4.jpg')";
		}
		function imgs5()
		{
			document.getElementById('D1').style.backgroundImage="url('spa5.jpg')";
		}
		function onimgs1()
		{
			document.getElementById('E1').style.height="175px";
		}
		function onimgs2()
		{
			document.getElementById('E2').style.height="175px";
		}
		function onimgs3()
		{
			document.getElementById('E3').style.height="175px";
		}
		function onimgs4()
		{
			document.getElementById('E4').style.height="175px";
		}
		function onimgs5()
		{
			document.getElementById('E5').style.height="175px";
		}
		function norimgs1()
		{
			document.getElementById('E1').style.height="";
		}
		function norimgs2()
		{
			document.getElementById('E2').style.height="";
		}
		function norimgs3()
		{
			document.getElementById('E3').style.height="";
		}
		function norimgs4()
		{
			document.getElementById('E4').style.height="";
		}
		function norimgs5()
		{
			document.getElementById('E5').style.height="";
		}

		function imgj1()
		{
			document.getElementById('F1').style.backgroundImage="url('jim1.jpg')";
		}
		function imgj2()
		{
			document.getElementById('F1').style.backgroundImage="url('jim2.jpg')";
		}
		function imgj3()
		{
			document.getElementById('F1').style.backgroundImage="url('jim3.jpg')";
		}
		function imgj4()
		{
			document.getElementById('F1').style.backgroundImage="url('jim4.jpg')";
		}
		function imgj5()
		{
			document.getElementById('F1').style.backgroundImage="url('jim5.jpg')";
		}
		function onimgj1()
		{
			document.getElementById('G1').style.height="175px";
		}
		function onimgj2()
		{
			document.getElementById('G2').style.height="175px";
		}
		function onimgj3()
		{
			document.getElementById('G3').style.height="175px";
		}
		function onimgj4()
		{
			document.getElementById('G4').style.height="175px";
		}
		function onimgj5()
		{
			document.getElementById('G5').style.height="175px";
		}
		function norimgj1()
		{
			document.getElementById('G1').style.height="";
		}
		function norimgj2()
		{
			document.getElementById('G2').style.height="";
		}
		function norimgj3()
		{
			document.getElementById('G3').style.height="";
		}
		function norimgj4()
		{
			document.getElementById('G4').style.height="";
		}
		function norimgj5()
		{
			document.getElementById('G5').style.height="";
		}