<?php
	session_start();

	$con=mysqli_connect('localhost','root','');
	mysqli_select_db($con,'hotel');

	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$uname = $_POST['uname'];
	$email = $_POST['email'];
	$gender = $_POST['gender'];
	$pass = sha1($_POST['password']);

	$sql="SELECT * FROM registration WHERE userName = '$uname'";
	$sqln="SELECT * FROM registration WHERE email = '$email'";

	$result = mysqli_query($con,$sql);
	$num = mysqli_num_rows($result);
	$resultn = mysqli_query($con,$sqln);
	$numn = mysqli_num_rows($resultn); 

	if($num == 1){
		echo "User name Already Taken";
	}
	else if ($numn == 1) {
		echo "Email Already Taken";
	}
	else{
		$reg="INSERT INTO registration(firstName, lastName, userName, email, gender, password) VALUES('$fname', '$lname', '$uname', '$email', '$gender', '$pass')";
		mysqli_query($con,$reg);
		echo "Registration Successful";
	}
?>