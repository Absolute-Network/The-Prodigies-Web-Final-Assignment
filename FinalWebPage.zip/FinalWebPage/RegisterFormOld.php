<?php
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$uname = $_POST['uname'];
	$email = $_POST['email'];
	$gender = $_POST['gender'];
	$pword = sha1($_POST['password']);

	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "hotel";

	$conn = mysqli_connect($servername, $username, $password, $database);

	if (!$conn) {
	  die("Error...!!!! Connection failed: " . mysqli_connect_error());
	}

	/*$sql = "CREATE TABLE Registration (
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	firstName VARCHAR(30) NOT NULL,
	lastName VARCHAR(30) NOT NULL,
	userName VARCHAR(30) NOT NULL,
	email VARCHAR(30) NOT NULL,
	gender VARCHAR(30) NOT NULL,
	password VARCHAR(200) NOT NULL,
	reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	)";

	if (mysqli_query($conn, $sql)) {
	  echo "Table Login created successfully...<br>";
	} else {
	  echo "Error creating table: " . mysqli_error($conn) . "<br>";
	}*/

	$sql = "INSERT INTO Registration (firstName, lastName, userName, email, gender, password)
	VALUES ('$fname', '$lname', '$uname', '$email', '$gender', '$pword');";

	if (mysqli_query($conn, $sql)) {
	  echo "New record created successfully...<br>";
	} else {
	  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bootstrap Example</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<style type="text/css">
		.top{
			background-color: cyan;
		}
		table, th, td {
			border: 1px solid white;
		}
		td{
			background-color: rgb(245, 245, 220);
		}
	</style>
</head>

<body>
	<div class="container">            
		<table class="table table-striped" style="margin-top: 50px;">
			<thead>
				<tr class="top">
					<th>First Name</th>
					<th>Last Name</th>
					<th>User Name</th>
					<th>Email</th>
					<th>Gender</th>
					<th>Password</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php echo "$fname"; ?></td>
					<td><?php echo "$lname"; ?></td>
					<td><?php echo "$uname"; ?></td>
					<td><?php echo "$email"; ?></td>
					<td><?php echo "$gender"; ?></td>
					<td><?php echo "$pword"; ?></td>
				</tr>
			</tbody>
		</table>
	</div>
</body>
</html>