<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>RegistrationForm_v1 by Colorlib</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
		<style type="text/css">
			/*@import url(https://fonts.googleapis.com/css?family=Roboto:400,300,500);
			*:focus {
			  	outline: none;
			}*/
			.pay-logo{
				position: absolute;
				top: 20px;
				left: 50%;
				transform: translateX(-50%);
				width: 105px;
				height: 105px;
				background-color: white;
				border-radius: 50%;
				box-shadow: 0 0 10px;
				text-align: center;
				line-height: 85px;
				border: 5px solid gold;
			}

			#logo
			{
				margin-top: -5px;
				margin-left: -3px;
			}

			img{
				border-radius: 5px;
			}
		</style>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	</head>

	<body>

		<div class="wrapper" style="background-color: rgba(0, 0, 0, 0.7);">
			<div class="inner" style="border: 5px solid gold; border-radius: 5px;">
				<div class="pay-logo">
					<img src="logo2.png" width="100" height="100" id="logo">
			    </div>
				<div class="image-holder" style="margin-top: 120px;">
					<img src="images/2.jpg" alt="Hotel Image">
				</div>
				<form action="registration.php" method="POST" oninput="rpassword.setCustomValidity(rpassword.value != password.value ? 'Passwords do not match.' : '')">
					<h3>Registration Form</h3>
					<div class="form-group">
						<input type="text" placeholder="First Name" class="form-control" name="fname" required>
						<input type="text" placeholder="Last Name" class="form-control" name="lname" required>
					</div>
					<div class="form-wrapper">
						<input type="text" placeholder="Username" class="form-control" name="uname" width="100%" required>
						<!--<i class="zmdi zmdi-account"></i>-->
					</div>
					<div class="form-wrapper">
						<input type="email" placeholder="Email Address" class="form-control" name="email" required>
						<!--<i class="zmdi zmdi-email"></i>-->
					</div>
					<div class="form-wrapper">
						<select name="gender" class="form-control" required>
							<option value="" disabled selected>Gender</option>
							<option value="Male">Male</option>
							<option value="Femal">Female</option>
							<option value="Other">Other</option>
						</select>
						<!--<i class="zmdi zmdi-caret-down" style="font-size: 17px"></i>-->
					</div>
					<div class="form-wrapper">
						<input type="password" placeholder="Password" name="password" class="form-control" required>
						<!--<i class="zmdi zmdi-lock"></i>-->
					</div>
					<div class="form-wrapper">
						<input type="password" placeholder="Confirm Password" name="rpassword" class="form-control" required>
						<!--<i class="zmdi zmdi-lock"></i>-->
					</div>
					<button type="submit">Register
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
				</form>
			</div>
		</div>
	</body>
</html>